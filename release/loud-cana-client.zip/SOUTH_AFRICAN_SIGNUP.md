# South African signup and age-check operating guide

This guide describes the application's controls and the business's operating duties. The primary sources below were checked on **22 October 2026**. The software does not certify that a business, product, transaction, or privacy programme complies with every applicable law.

## Legal basis and limits

- **Adult age is 18.** Section 17 of the Children's Act 38 of 2005 says a child becomes a major on reaching 18. Section 1 of the Cannabis for Private Purposes Act 7 of 2024 defines an adult person as someone who is 18 or older. The Department of Justice's 3 February 2026 statement confirms this age threshold. The earlier 21+ wording in the app was not the South African statutory adult threshold.
- **Private use is not a general commercial-sales permission.** The Department of Justice states that the Constitutional Court's private-use decision did not extend to buying and selling cannabis. A membership account, an ID check, or passing questions does not authorise cannabis sales or delivery. Existing business-sales gates remain necessary and must reflect genuine authority for the actual products and service area.
- **Do not represent the 2024 Act as fully commenced.** The official Act listing currently says **“Commencement: To be proclaimed.”** Section 8 provides for presidential proclamation and allows different commencement dates for different provisions. The February 2026 regulations notice is a draft consultation, not proof that its proposed limits are in force. No later commencement proclamation was established in this source review; this is not an exhaustive Gazette certification.
- **The random quiz is a business onboarding choice.** The reviewed sources do not prescribe this quiz, make it proof of age, or specify a particular electronic identity-verification vendor. The app uses questions to check responsible-use awareness. New applications require ID and selfie uploads followed by a recorded manual staff comparison. Older original-ID checks remain a legacy path. Neither process certifies document authenticity or legal commercial-sales authority.

## What happens during signup

1. The applicant provides their name, email, password and date of birth, confirms adulthood, accepts the account terms/privacy notice, and consents to the stated age-check processing.
2. The server validates the calendar date and calculates the applicant's age using the server's current date in **`Africa/Johannesburg`**. Invalid dates, future dates, and applicants younger than 18 are rejected. Changing the browser clock does not change server eligibility.
3. The browser requests `GET /api/members/signup-challenge`. The server chooses **three questions** from its responsible-use bank using cryptographic randomness and shuffles their answer choices. Each fresh application receives a new challenge; the immediately preceding question combination is not reused. The pool may be reused over time, so this does not promise globally unique questions for every person forever.
4. A challenge is bound to a secure browser cookie, expires after **15 minutes**, allows at most **three answer attempts**, and can be consumed only once. Requesting replacement questions invalidates the earlier unused challenge for that browser. Answer keys are not returned by the public API.
5. Correct answers allow a restricted account with **pending ID check** status; they never produce verified status. New applications also require a government-issued photo ID image and a face photograph, uploaded through the authenticated account flow after separate, specific consent to upload and staff review. The business must configure the private upload key before the service accepts photographs.
6. The account may use its profile and saved favourites while ordering remains unavailable. Authorised staff must actually review the current uploaded ID/selfie and application before recording a decision. Uploads do not automatically verify age, identity, document authenticity or liveness.

Questions address lawful/responsible conduct, privacy and account safety. They are not password-recovery questions and do not request family-history secrets, health diagnoses, medication histories, document numbers or images in answer fields. Identity images are handled only by the separate secure upload step. An ID photograph may visibly include a document number; the application does not extract or request a separate ID-number field.

## Verification states

| State | Meaning and next action |
| --- | --- |
| Submission required (`required`) | No current eligible submission is available. The member must complete a new date declaration, consent, questions and required identity uploads from their account. This also applies after a profile-name change invalidates verification. |
| Pending ID check (`pending`) | The declared date passed the server's 18+ calculation and questions were completed. The current ID/selfie images must be submitted and manually reviewed; pending status is not verified identity. |
| 18+ ID checked (`verified`) | An authenticated staff session recorded the applicable manual ID/selfie review, or a legacy in-person original-ID check. This is a manual business verification, not a government API, biometric match or automated identity result. |
| Not verified (`rejected`) | The staff check could not confirm the application. The member must submit a new age-check application before another review. |

Changing a member's name invalidates the current verification and removes any pending date of birth. The applicant must resubmit and be checked against the new name. A password change does not itself establish or replace age verification.

## Staff's actual ID-and-selfie review

Management uses the shared **`/login`** page. The administrator enters **`admin`** with `ADMIN_PASSWORD` and creates individual employees in **Admin → Staff accounts**. Each employee signs in with their assigned username and password; members use their registered email and do not receive management access. Administrators reach `/admin`, employees reach `/staff`, and only administrators can use Overview or manage employee accounts. The public storefront has no staff-access link. A shared `STAFF_PASSWORD` is a legacy option and is not required for individual employees. See [the setup guide](STAFF_SETUP.md). Identity submissions additionally require an independent stable **`IDENTITY_UPLOAD_KEY`** of exactly 64 hexadecimal characters. Generate it privately with `openssl rand -hex 32`, keep the result out of source/chat/build logs, and back it up securely separately from the database. Missing or invalid key configuration blocks image submission. See [the technical upload guide](IDENTITY_VERIFICATION.md).

1. Sign in at **`/login`** with the authorised admin/staff role and select **Age Checks** in the appropriate management workspace. Open the pending applicant and the current private ID/selfie pair. The Members directory lists accounts and status without including DOB or images; ordinary member sessions cannot access the staff directory or review photographs.
2. Inspect the ID image for a clear government-issued photo document showing the applicant's full name, date of birth and photograph. Compare the document photograph with the submitted face photograph and compare the name/birth date with the current application. Review obvious inconsistencies and validity information where applicable. If the details cannot be confirmed confidently, reject or follow the business's approved escalation process.
3. Independently confirm the ID shows an age of **at least 18 today**. Only after actually performing the review, select both required identity-comparison and age attestations, then confirm the decision. The recorded method for new uploads is `uploaded_id_selfie`; the decision is tied to the currently displayed application and upload revision. A stale review must be refreshed rather than applied to replacement images.
4. If the check cannot be completed, choose the structured rejection reason: identity not confirmed, details mismatch, or unable to verify. Do not enter document numbers or unnecessary personal details into notes. Do not ask applicants to email documents or attach them to a contact message.
5. The application records the decision, method, timestamps and pseudonymous authenticated-reviewer reference. The live pending images are removed after approval or rejection, and the pending birth date is removed after the decision. Reviewers should refresh if another staff session has already acted.

Older original-ID applications retain their legacy **in-person** review method. For that method, staff must actually inspect the person and original valid photo ID; it cannot be recorded as completed from an unseen document. New applications use the required upload workflow rather than bypassing it with a legacy attestation.

This is **manual image comparison**. No face-matching algorithm, liveness detection, government database, document-authenticity service or third-party identity-verification provider is connected. A selfie may be an uploaded image and is not proof that the person is live or present. Staff approval records the review actually performed; it does not turn limited visual evidence into a government-verified identity. The owner must decide whether this method supplies adequate assurance for the business's actual obligations.

The business must restrict staff access and train reviewers. Create a separate account for each employee through Admin → Staff accounts. Password resets, disabling and username changes invalidate that employee's existing sessions. Review records retain an authenticated reviewer reference; maintain an appropriate authorised-reviewer record and accountability process rather than treating a stored reference as proof that an inspection occurred. Any retained legacy shared login cannot identify an individual employee. The software cannot make an unperformed review genuine.

## Ordering remains separately controlled

An order request requires both:

- A signed-in member whose current age-check status is `verified`.
- Every existing business launch requirement, including genuine sales/delivery authority, approved actual catalog and postal coverage, configured store/support details, secure staff access, and enabled order intake.

Neither condition replaces the other. A verified member cannot make an unauthorised business lawful. A fully configured business cannot accept this app's order request from a member who has not completed the ID-age check. The app does not collect online payments, automatically dispatch drivers, or guarantee fulfilment.

## Data minimisation and retention

The flow stores a pending declared birth date and a private encrypted ID/selfie pair for authorised review. Public member responses expose status and relevant timestamps, not the full birth date, image bytes or private image URLs. Full DOB and image access belong only in authenticated staff review, not the general Members directory.

- Each source image must be **JPG/JPEG, PNG or WebP**, no more than **6 MiB**, at least **200 × 200 pixels**, and no more than **20 megapixels**. The server actually decodes the input, normalises it to metadata-stripped JPEG and limits either side to 2400 pixels. A filename or browser MIME declaration alone is not accepted as format proof.
- Images are encrypted with **AES-256-GCM** before storage in SQLite using the independent hosting key. They are not placed in public static assets. Authenticated staff image responses are private and not cacheable. Database encryption does not remove staff/host access duties or the need for HTTPS.
- Live pending images are removed after **approval, rejection, replacement, name/application invalidation, account deletion or at most seven days pending**. An expired image pair must be resubmitted; staff cannot approve missing or outdated images.
- The pending birth date has a **maximum 30-day** period and is removed after approval/rejection or application expiry. Cleanup runs on startup, periodically while the server runs, and during relevant operations. A stopped server processes expired records when it runs again.
- ID photographs may visibly contain document numbers and other personal details. The app does not extract a separate document-number field, perform automated facial matching or create biometric templates. It retains minimal outcome/audit metadata, consent/pass timestamps, policy version and question identifiers, not personal answer histories.
- Closing an account removes its member profile, favourites, sessions and linked age-check/upload records. Independently submitted order records remain subject to the business's separate lawful retention process.
- Live-database deletion does **not** immediately erase older backups, SQLite WAL copies, host snapshots or all underlying storage. The owner must define backup rotation, restricted access, restoration handling and eventual deletion for DOB and encrypted images. Encryption-key backups must be protected separately; losing or silently replacing the key prevents decryption of still-pending images.

Seven-day image retention and the 30-day pending-DOB cap are application operating policies, **not claims that POPIA prescribes those durations**. The owner must assess the necessary retention for the actual service, including review/audit records and backup copies. A longer legal or operational need must not be assumed merely because data is encrypted.

## Owner privacy and hosting responsibilities

POPIA requires lawful and reasonable processing; adequate, relevant and non-excessive collection; a defined lawful purpose; appropriate notices; limited retention; and security safeguards. Before operating the process with real applicants, the owner must:

- Supply genuine responsible-party identity, address and monitored contact details, explain the processing purpose and required/optional fields, and provide a usable data-rights/contact process.
- Document the lawful basis, purpose, recipients, retention schedule and access controls for account, ID and face-photo processing. Provide the specific upload/review notice and assess any additional duties relevant to the actual identity information and processing. Do not treat accepting all terms as unlimited permission for other uses or marketing.
- Restrict the database, staff dashboard, hosting account and backups; keep HTTPS enabled; manage the administrator secret, individual employee credentials and independent image-encryption key securely; train manual reviewers; and test backup/restore and deletion procedures. Never request identity photographs through email or ordinary contact channels.
- Review the actual hosting/operator arrangements and required written agreements. The provided Render Blueprint uses **Frankfurt**. POPIA section 72 governs foreign transfers and provides conditions such as adequate protection under law/binding agreement, consent, or another listed basis; overseas hosting must not be assumed automatically compliant or automatically prohibited.
- Confirm the existing Render service has a **persistent disk mounted at `/var/data`** and **`DATABASE_PATH=/var/data/orders.sqlite`**. The disk mount has not been established from the public API. Without persistent storage, accounts, product edits, encrypted pending photographs, sessions and audit information may be lost on redeployment.

These are owner operating duties, not an additional code-approval step. Application flags, a quiz, or this guide do not certify legal compliance. The genuine business authorisation and privacy arrangements must match the business actually being operated.

## Primary sources checked

1. **Children's Act 38 of 2005, section 17:** “A child … becomes a major upon reaching the age of 18 years.” [Official Department of Justice PDF](https://www.justice.gov.za/legislation/acts/2005-038%20childrensact.pdf).
2. **Cannabis for Private Purposes Act 7 of 2024, sections 1 and 8:** definition of an adult and proclamation-based commencement. The current official page states “To be proclaimed.” [Government Act listing](https://www.gov.za/documents/acts/cannabis-private-purposes-act-7-2024-english-sepedi-03-jun-2024) and [Government Gazette Act PDF](https://www.gov.za/sites/default/files/gcis_document/202406/50744-03-06-cannabisforprivatepurposesact-72024.pdf).
3. **Department of Justice statement, 3 February 2026:** adults are persons aged 18 or older; the Constitutional Court ruling did not extend to buying and selling cannabis; commercial matters fall outside the private-use Act's scope. [Official Government statement](https://www.gov.za/news/media-statements/justice-and-constitutional-development-draft-regulations-under-cannabis).
4. **Draft regulations consultation, 2 February 2026:** comments invited until 5 March 2026; this is a draft notice, not proof of final regulations or commencement. [Official notice](https://www.gov.za/documents/notices/cannabis-private-purposes-act-regulations-comments-invited-02-feb-2026).
5. **Protection of Personal Information Act 4 of 2013:** sections 9–14, 18–21 and 72 cover lawful processing, minimality, purpose/retention, notices, safeguards/operators and foreign transfers. [Official Department of Justice PDF](https://www.justice.gov.za/legislation/acts/2013-004.pdf).
